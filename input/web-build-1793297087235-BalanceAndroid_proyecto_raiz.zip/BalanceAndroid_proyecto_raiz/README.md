# Balance Android (prototipo)

Aplicación Android mínima que abre el prototipo web local `app/src/main/assets/index.html` dentro de un WebView. No necesita cuenta bancaria ni conexión a bancos.

## Compilar
- JDK 17
- Gradle 8.9
- Android SDK platform 35
- Ejecutar: `gradle assembleDebug`
- APK: `app/build/outputs/apk/debug/app-debug.apk`

También incluye un workflow de GitHub Actions (`Build Balance APK`) para compilar en la nube y descargar el APK como artifact.

## Estado y limitaciones
- Es una APK de prueba basada en el prototipo HTML, no una versión financiera validada.
- El almacenamiento usa el almacenamiento local del WebView; desinstalar o borrar datos puede eliminar registros.
- No incluye todavía notificaciones nativas, sincronización ni cifrado de base de datos.
- Revisar los cálculos de cuotas y vencimientos antes de usarla para decisiones financieras reales.
